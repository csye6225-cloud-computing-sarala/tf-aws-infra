import formData from "form-data";
import Mailgun from "mailgun.js";
import "dotenv/config";

const DOMAIN = process.env.DOMAIN;

// Initialize Mailgun client
const mailgun = new Mailgun(formData);
const mg = mailgun.client({
  username: "api",
  key: process.env.MAILGUN_API_KEY,
});

export const handler = async (event) => {
  try {
    // Validate SNS event structure
    if (!event.Records || event.Records.length === 0) {
      throw new Error("Event does not contain Records");
    }

    // Extract message from SNS
    const snsMessage = event.Records[0].Sns.Message;
    console.log("Received SNS Message:", snsMessage);

    // Parse the SNS message
    let payload;
    try {
      payload = JSON.parse(snsMessage);
      console.log("Parsed Payload:", payload);
    } catch (parseError) {
      throw new Error("Failed to parse SNS message");
    }

    console.log("Payload:", JSON.stringify(payload, null, 2));

    const { email, id, token, expiryTime } = payload;

    if (!email) {
      throw new Error("Email is missing from the payload");
    }
    if (!id) {
      throw new Error("id is missing from the payload");
    }
    if (!token) {
      throw new Error("Verification token is missing from the payload");
    }

    const verificationUrl = `http://${DOMAIN}/v1/user/verify-email?token=${token}`;
    let emailStatus = "Pending";
    let errorMessage = "";
    let response;

    // try {
    //   // Save the token in the database
    //   await VerificationToken.create({
    //     email,
    //     token,
    //     expiryTime: expiryTime
    //       ? new Date(expiryTime)
    //       : new Date(Date.now() + 24 * 60 * 60 * 1000), // Use provided expiryTime or fallback to 24 hours
    //   });

    //   console.log("Verification token saved in the database.");
    // } catch (dbError) {
    //   console.error(
    //     "Failed to save verification token in the database:",
    //     dbError
    //   );
    //   throw new Error("Could not save verification token.");
    // }

    const msgdata = {
      from: `noreply@${DOMAIN}`,
      to: "sharanappakanakagi.s@northeastern.edu",
      subject: "Verify Your Email Address",
      template: "verify_email",
      "h:X-Mailgun-Variables": JSON.stringify({
        email: email,
        verification_url: verificationUrl,
      }),
    };

    console.log("msgdata data:", msgdata);

    try {
      response = await mg.messages.create(DOMAIN, msgdata);
      emailStatus = "Sent";
    } catch (error) {
      emailStatus = "Failed";
      errorMessage = error.message;
      console.error("Failed to send email: ", error);
    }
    console.log("Mailgun Response:", response);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Email sent successfully." }),
    };
  } catch (error) {
    console.error("Error in Lambda function:", error);
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "Bad Request", error: error.message }),
    };
  }
};
