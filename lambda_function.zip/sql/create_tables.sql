-- sql/create_tables.sql

CREATE TABLE IF NOT EXISTS email_verifications (
  user_id INT NOT NULL,
  email VARCHAR(255) NOT NULL,
  token VARCHAR(64) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  sent_at TIMESTAMP NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, token)
);

CREATE TABLE IF NOT EXISTS email_logs (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  sent_at TIMESTAMP NOT NULL DEFAULT NOW()
);

