-- sql/cleanup_tokens.sql

DELETE FROM email_verifications
WHERE expires_at < NOW();
