// handler.js

const AWS = require("aws-sdk");
const Mailgun = require("mailgun.js");
const formData = require("form-data");
const { Pool } = require("pg");
const crypto = require("crypto");

const secretsManager = new AWS.SecretsManager();

let pool;
let mg;

const mailgun = new Mailgun(formData);

// Function to fetch secrets
const getSecret = async (secretArn) => {
  const data = await secretsManager
    .getSecretValue({ SecretId: secretArn })
    .promise();
  return JSON.parse(data.SecretString);
};

// Initialization function to set up Pool and Mailgun client
const initialize = async () => {
  if (!pool) {
    // Retrieve database credentials
    const dbSecrets = await getSecret(process.env.DB_PASSWORD_SECRET);
    pool = new Pool({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: dbSecrets.DB_PASSWORD,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT,
    });
  }

  if (!mg) {
    // Retrieve Mailgun credentials
    const mailgunSecrets = await getSecret(process.env.MAILGUN_SECRET_ARN);
    mg = mailgun.client({
      username: "api",
      key: mailgunSecrets.MAILGUN_API_KEY,
      url: `https://api.mailgun.net/v3/${mailgunSecrets.MAILGUN_DOMAIN}`,
    });
  }
};

exports.handler = async (event) => {
  try {
    await initialize();
  } catch (initError) {
    console.error("Initialization error:", initError);
    throw initError; // Fail the Lambda invocation
  }

  const processRecord = async (record) => {
    if (record.EventSource !== "aws:sns") return;

    const message = JSON.parse(record.Sns.Message);
    const { userId, email, name } = message;

    try {
      // Validate message content
      if (!userId || !email || !name) {
        throw new Error("Invalid message format");
      }

      // Generate verification token and link
      const token = generateToken();
      const verificationLink = `https://yourapp.com/verify?token=${token}`;

      // Send verification email via Mailgun
      const emailData = {
        from: process.env.EMAIL_SENDER,
        to: email,
        subject: "Verify Your Email",
        text: `Hello ${name}, please verify your email by clicking the link below. This link expires in 2 minutes.\n\n${verificationLink}`,
        html: `<p>Hello ${name},</p><p>Please verify your email by clicking the link below. This link expires in 2 minutes.</p><a href="${verificationLink}">Verify Email</a>`,
      };

      await mg.messages.create(process.env.MAILGUN_DOMAIN, emailData);

      // Log the email sent
      const logClient = await pool.connect();
      try {
        await logClient.query("INSERT INTO email_logs (email) VALUES ($1)", [
          email,
        ]);
      } finally {
        logClient.release();
      }

      // Store email verification details in RDS
      const client = await pool.connect();
      try {
        const expiry = new Date(Date.now() + 2 * 60 * 1000); // 2 minutes from now
        await client.query(
          "INSERT INTO email_verifications (user_id, email, token, expires_at, sent_at) VALUES ($1, $2, $3, $4, NOW())",
          [userId, email, token, expiry]
        );
      } finally {
        client.release();
      }
    } catch (error) {
      console.error("Error processing message:", error);
      // Optionally, implement retry logic or send to Dead Letter Queue (DLQ)
    }
  };

  // Process all records concurrently
  const processingPromises = event.Records.map(processRecord);
  await Promise.all(processingPromises);

  return { status: "Done" };
};

// Utility function to generate a unique token
function generateToken() {
  return crypto.randomBytes(32).toString("hex");
}
