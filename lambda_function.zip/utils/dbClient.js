// utils/dbClient.js
const { Client } = require("pg");
const dbConfig = require("../config/config.json");

const getDbClient = () => {
  return new Client({
    user: dbConfig.DB_USER,
    host: dbConfig.DB_HOST,
    database: dbConfig.DB_NAME,
    password: dbConfig.DB_PASSWORD,
    port: dbConfig.DB_PORT || 5432,
  });
};

module.exports = { getDbClient };
